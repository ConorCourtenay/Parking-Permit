﻿using System;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Assignment6
{
    class MainClass
    {
        static void Main(){

            MySqlConnection conn;
            String myconnect;

            myconnect = "Server=mysql1.it.nuigalway.ie; Database=mydb2984; Uid=mydb2984cc; Pwd=wu6hij;  " ;

            MySqlDataReader rdr = null;
            conn = new MySqlConnection(myconnect);

            try{
                


                conn.Open();

                MySqlCommand cmd = new MySqlCommand("select Student_ID, Vehicle_Model, Registration, Owner, Apartment from Vehicle", conn);

                String insert = @"insert into Vehicle(Student_ID, Vehicle_Model, Registration, Owner, Apartment)values(444, 'BMW', '56789S', 'Katie', 4 )";
                MySqlCommand cmd2 = new MySqlCommand(insert,conn);
                cmd2.ExecuteNonQuery();

                rdr=cmd.ExecuteReader();

                while(rdr.Read()){
                    Console.WriteLine(rdr[0]);
                    Console.WriteLine(rdr[1]);
                    Console.WriteLine(rdr[2]);
                    Console.WriteLine(rdr[3]);
                    Console.WriteLine(rdr[4]);
                }
                rdr.Close();

                MySqlCommand cmd3 = new MySqlCommand("update Vehicle set Owner='Jack Courtenay' where Student_ID=111",conn);

                cmd3.ExecuteNonQuery();

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Console.WriteLine("\n");
                    Console.WriteLine(rdr[0]);
                    Console.WriteLine(rdr[1]);
                    Console.WriteLine(rdr[2]);
                    Console.WriteLine(rdr[3]);
                    Console.WriteLine(rdr[4]);
                }



            }finally{
                if(rdr!=null){
                    rdr.Close();
                }

                if(conn!=null){
                    conn.Close();
                }

            }
        }
    }
}
