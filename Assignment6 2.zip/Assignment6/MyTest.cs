﻿using NUnit.Framework;
using System.Collections.Generic;
using MySql.Data;
using MySql.Data.MySqlClient;
using System;
namespace Assignment6
{
    [TestFixture()]
    public class MyTest
    {
        static MySqlConnection conn = new MySqlConnection(myconnect);
        static String myconnect = "Server=mysql1.it.nuigalway.ie; Database=mydb2984; Uid=mydb2984cc; Pwd=wu6hij;  ";
        static MySqlDataReader rdr = null;

        [Test()]
        public void TestPermit()
        {   //testing the get valid permits in system
            conn = new MySqlConnection(myconnect);

            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT COUNT(Permit.permitNo) As 'Valid permits in use' FROM Permit INNER JOIN Vehicle ON Permit.permitNo=Vehicle.permit WHERE Permit.Paid='yes' OR Permit.Paid='Yes'", conn);

            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine("Test valid permits on system "); 
                String p = (rdr[0].ToString());
                Console.WriteLine(rdr[0]);
                //assert that the valid permits in system is equal to 4
                Assert.AreEqual(p, "4");
            }


            rdr.Close();
            conn.Close();



        }
        [Test()]
        public void TestGetVehicle(){
            conn = new MySqlConnection(myconnect);

            conn.Open();
            //test get vehicle method 
            MySqlCommand cmd = new MySqlCommand("select * from Vehicle WHERE Student_ID=111", conn);



            rdr = cmd.ExecuteReader();
            Console.WriteLine("Test Get Vehicle method - reading ID of first vehicle");
            while (rdr.Read())
            {
                Console.WriteLine(rdr[0]);
                String t=rdr[0].ToString();
                //assert ID is equal to 111
                Assert.AreEqual(t, "111"); 
            }
            rdr.Close();
            conn.Close(); 
                

        }

        [Test()]
        public void testUniquePermit()
        {
            conn = new MySqlConnection(myconnect);

            conn.Open();
            //test amount of unique cars on permit 1

            MySqlCommand cmd = new MySqlCommand("SELECT `permit`, COUNT(permit) FROM `Vehicle` WHERE permit=1 GROUP BY `permit`", conn);

            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine("Testing unique cars on each permit");
                String t1 = rdr[1].ToString();
                String t2 = rdr[0].ToString();
                Console.WriteLine("There is " + rdr[1] + " unique car(s) on permit " + rdr[0]);
                //assert permit is equal to 1 and there are two cars on it
                Assert.AreEqual(t1, "2");
                Assert.AreEqual(t2, "1");
            }



        }
        [Test()]
        public void testUpdate(){
            //call the update permit method
            Vehicle.updatePermit("3");

            conn = new MySqlConnection(myconnect);

            conn.Open();
            //select   permit 1 from database
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM `Permit` WHERE permitNo=1", conn);

            rdr = cmd.ExecuteReader();

            while(rdr.Read()){
                //output permit
                Console.WriteLine("Testing if table updated correctly"); 
                String t1 = rdr[0].ToString();
                String t2 = rdr[1].ToString();
                String t3 = rdr[2].ToString();
                //test if data members are equal
                Assert.AreEqual(t1, "1");
                Assert.AreEqual(t2,"Yes");
                Assert.AreEqual(t3, "Yes");
            }



        }





    }
}
