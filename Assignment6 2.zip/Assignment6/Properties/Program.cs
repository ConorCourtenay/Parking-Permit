﻿using System;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Assignment6
{
    class MainClass
    {


        protected static void Main(){
            //call menu function where all functions can be accessed
            Vehicle.menu();



        }
    }
}
