﻿using NUnit.Framework;
using System;
namespace Assignment6
{
    [TestFixture()]
    public class NUnitTestClass
    {
        [Test()]
        public void TestCase()
        {
        }
    }
}
